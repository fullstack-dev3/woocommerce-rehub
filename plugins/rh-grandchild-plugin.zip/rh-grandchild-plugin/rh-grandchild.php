<?php
/*
Plugin Name: RH Grandchild plugin
Plugin URI: https://1.envato.market/RDKjR
Description: Specialized plugin for customization ReHub themes
Version: 1.0.5
Author: Check docs
Author URI: http://rehubdocs.wpsoul.com/docs/rehub-plugins-add-ons/rh-grandchild-plugin/
Text Domain: rh-grandchild-plugin
Domain Path: /lang/
License: GPL2
*/

/* Exit if accessed directly */
defined( 'ABSPATH' ) || exit;

/* Constants */
if ( ! defined( 'RH_GRANDCHILD_VER' ) ) {
	define( 'RH_GRANDCHILD_VER', '1.0.5' );
}

if ( ! defined( 'RH_GRANDCHILD_DIR' ) ) {
	define( 'RH_GRANDCHILD_DIR', plugin_dir_path( __FILE__ ) ); // end with "/"
}

if ( ! defined( 'RH_GRANDCHILD_URL' ) ) {
	define( 'RH_GRANDCHILD_URL', plugin_dir_url( __FILE__ ) ); // end with "/"
}

// Custom functions go here
function rh_grandchild_func() {
	$current_theme = get_option( 'template' );
	if( 'rehub' == $current_theme || 'rehub-theme' == $current_theme ) {
		include( RH_GRANDCHILD_DIR .'rh-grandchild-func.php' );
	}
}
add_action( 'init', 'rh_grandchild_func' );

/* Loads the plugin's text domain for localization. */
function rh_grandchild_textdomain() {
	load_plugin_textdomain( 'rh-grandchild-plugin', FALSE, dirname( plugin_basename( __FILE__ ) ) .'/lang/' );
}
add_action( 'plugins_loaded', 'rh_grandchild_textdomain' );

/* Search for templates in plugin 'templates' dir, and load if exists */
function rh_grandchild_template( $template ) {
  if ( file_exists( untrailingslashit( plugin_dir_path( __FILE__ ) ) . '/' . basename( $template ) ) )
    $template = untrailingslashit( plugin_dir_path( __FILE__ ) ) . '/' . basename( $template );
  return $template;
}
add_filter( 'template_include', 'rh_grandchild_template', 12 );

/* Here, we check Buddypress files from plugin first */
function rh_grandchild_load_template_filter( $stack ) {   
	array_unshift($stack, untrailingslashit( RH_GRANDCHILD_DIR ) . '/buddypress');
	return $stack;
}
add_filter( 'bp_get_template_stack', 'rh_grandchild_load_template_filter', 12 );

/* Search for woocommerce templates in plugin 'woocommerce' dir, and load if exists.
 * Some templates from the WC templates directory may need to be placed in the root directory of the plugin.
 */
function rh_grandchild_wc_template( $located, $template_name ) {
	if ( file_exists( untrailingslashit( RH_GRANDCHILD_DIR ) . '/woocommerce/'. $template_name ) )
		$located = untrailingslashit( RH_GRANDCHILD_DIR ) . '/woocommerce/'. $template_name;
  	return $located;
}
add_filter( 'wc_get_template', 'rh_grandchild_wc_template', 12, 2 );

/* Redirect Geo My WP Search result templates (backend) */
function bd_gmw_get_templates_path( $path ){
	$new_path = RH_GRANDCHILD_DIR . 'geo-my-wp';

	if( is_dir( $new_path ) ) {
		$path = $new_path;
	}
	return $path;
}
add_filter( 'gmw_get_templates_path', 'bd_gmw_get_templates_path', 12 );

/* Redirect Geo My WP Search result templates (frontend) */
function bd_gmw_get_template_path( $path ){
		$custom_path_uri = array(
			'path' => RH_GRANDCHILD_DIR . 'geo-my-wp',
			'uri'  => RH_GRANDCHILD_URL . 'geo-my-wp',
		);
	if( is_dir( $custom_path_uri['path'] ) ) {
		$path = $custom_path_uri;
	}
	return $path;
}
add_filter( 'gmw_get_template_path_uri', 'bd_gmw_get_template_path', 12 );

/* Redirect Dokan template */
function bd_dokan_locate_template( $template, $template_name ){
    if ( file_exists( untrailingslashit( RH_GRANDCHILD_DIR ) ."/dokan/{$template_name}" ) ) {
        $template = untrailingslashit( RH_GRANDCHILD_DIR ) ."/dokan/{$template_name}";
    }
	return $template;
}
add_filter( 'dokan_locate_template', 'bd_dokan_locate_template', 12, 2 );

/* Redirect Dokan template part */
function bd_dokan_get_template_part( $template, $slug ){
    if ( file_exists( untrailingslashit( RH_GRANDCHILD_DIR ) ."/dokan/{$slug}.php" ) ) {
        $template = untrailingslashit( RH_GRANDCHILD_DIR ) ."/dokan/{$slug}.php";
    }
	return $template;
}
add_filter( 'dokan_get_template_part', 'bd_dokan_get_template_part', 12, 2 );

/* Custom styles and scripts go here */
function rh_grandchild_style() {
	$css_modified = filemtime( RH_GRANDCHILD_DIR .'rh-grandchild-style.css' );
	$js_modified = filemtime( RH_GRANDCHILD_DIR .'rh-grandchild-script.js' );
    wp_enqueue_style( 'grandchild-style', RH_GRANDCHILD_URL . 'rh-grandchild-style.css', false, $css_modified );
	wp_enqueue_script( 'grandchild-script', RH_GRANDCHILD_URL . 'rh-grandchild-script.js', array( 'jquery' ), $js_modified, true );
}
//add_action( 'wp_enqueue_scripts', 'rh_grandchild_style', 12 ); //uncomment this to use custom CSS or JS codes

?>