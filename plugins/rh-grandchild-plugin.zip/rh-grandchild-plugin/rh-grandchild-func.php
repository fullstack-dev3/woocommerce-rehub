<?php
defined( 'ABSPATH' ) || exit;

/* Custom WP functions */